%code requires {
#include "treenode.h"
#include "tokenclass.h"
}

%define parse.lac full
%define parse.error verbose
%debug

%{
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "errorhandler.h"
#include "treenode.h"

int yylex(void);
void yyerror(const char*);

extern FILE* yyin;
extern int yydebug;

TreeNode* ASTRoot = nullptr;
%}

%union {
    int NUMBER;
    TreeNode::VarType varType;
    TreeNode* node;
    TokenClass* tokenData;
};

%token <tokenData> ID NUMCONST CHARCONST STRINGCONST SEMICOLON STATIC COMMA COLON LBRACKET RBRACKET LPAREN RPAREN LBRACE RBRACE ASSIGN ADDASS SUBASS MULASS DIVASS INC DEC LEQ LT GT GEQ EQ NEQ MIN MAX PLUS MINUS STAR DIVIDE MOD QUESTION INT BOOL CHAR IF THEN ELSE WHILE DO FOR RETURN TO BY BREAK OR AND NOT TRUE FALSE
%type <node> program declList decl varDecl scopedVarDecl varDeclList varDeclInit varDeclId funDecl parms parmList parmTypeList parmIdList parmId stmt otherStmts expStmt compoundStmt localDecls stmtList selectStmt matchedStmt unmatchedStmt iterRange returnStmt breakStmt exp simpleExp andExp unaryRelExp relExp relop minmaxExp minmaxop sumExp sumop mulExp mulop unaryExp unaryop factor mutable immutable call args argList constant
%type <varType> typeSpec

%%
program:
    declList    {ASTRoot = $1;}
    ;

declList:
    declList decl   {$$ = TreeNode::NodeList($1, $2);}
    | decl          {$$ = $1;}
    ;

decl:
    varDecl     {$$ = $1;}
    | funDecl   {$$ = $1;}   
    ;

varDecl:
    typeSpec varDeclList SEMICOLON  {$$ = TreeNode::PullUpTypeNode($2, $1); TreeNode::SetNodeListTypes($1, $2);}
    ;

scopedVarDecl:
    STATIC typeSpec varDeclList SEMICOLON   {$$ = TreeNode::PullUpTypeNode($3, $2); $$->isStatic = true; TreeNode::SetNodeListTypes($2, $3);}
    | typeSpec varDeclList SEMICOLON        {$$ = TreeNode::PullUpTypeNode($2, $1); TreeNode::SetNodeListTypes($1, $2);}
    ;

varDeclList:
    varDeclList COMMA varDeclInit   {$$ = TreeNode::NodeList($1, $3);}
    | varDeclInit                   {$$ = $1;}
    ;

varDeclInit:
    varDeclId                   {$$ = $1;}
    | varDeclId COLON simpleExp {$$ = TreeNode::PullUpNode($1, $3, nullptr, nullptr);}
    ;

varDeclId:
    ID                              {$$ = TreeNode::CreateVarDecl(nullptr, $1);}
    | ID LBRACKET NUMCONST RBRACKET {$$ = TreeNode::CreateVarDecl($3, $1); $$->isArray = true;}
    ;

typeSpec:
    INT     {$$ = TreeNode::VarType::INTEGER;} 
    | BOOL  {$$ = TreeNode::VarType::BOOLEAN;}
    | CHAR  {$$ = TreeNode::VarType::CHARACTER;}
    ;

funDecl:
    typeSpec ID LPAREN parms RPAREN stmt    {$$ = TreeNode::CreateFuncDecl($1, $4, $6, $2);}
    | ID LPAREN parms RPAREN stmt           {$$ = TreeNode::CreateFuncDecl(TreeNode::VarType::VOID, $3, $5, $1);}
    ;

parms:
    parmList    {$$ = $1;}
    |           {$$ = nullptr;}
    ;

parmList:
    parmList SEMICOLON parmTypeList {$$ = TreeNode::NodeList($1, $3);}
    | parmTypeList                  {$$ = $1;}
    ;

parmTypeList:
    typeSpec parmIdList {$$ = $2; TreeNode::SetNodeListTypes($1, $2);}
    ;

parmIdList:
    parmIdList COMMA parmId {$$ = TreeNode::NodeList($1, $3);}
    | parmId                {$$ = $1;}
    ;

parmId:
    ID                  {$$ = TreeNode::CreateParmExp($1);}
    | ID LBRACKET RBRACKET  {$$ = TreeNode::CreateParmExp($1); $$->isArray = true;}
    ;

stmt:
    selectStmt  {$$ = $1;}
    ;

otherStmts:
    expStmt         {$$ = $1;}
    | compoundStmt  {$$ = $1;}
    | returnStmt    {$$ = $1;}
    | breakStmt     {$$ = $1;}
    ;

expStmt:
    exp SEMICOLON   {$$ = $1;}
    | SEMICOLON     {$$ = nullptr;}
    ;

compoundStmt:
    LBRACE localDecls stmtList RBRACE   {$$ = TreeNode::CreateCompoundStmt($2, $3, $1);}
    ;

localDecls:
    localDecls scopedVarDecl    {$$ = TreeNode::NodeList($1, $2);}
    |                           {$$ = nullptr;}
    ;

stmtList:
    stmtList stmt   {$$ = TreeNode::NodeList($1, $2);}
    |               {$$ = nullptr;}
    ;

selectStmt:
    matchedStmt     {$$ = $1;}
    | unmatchedStmt {$$ = $1;}
    ;

matchedStmt:
    IF simpleExp THEN matchedStmt ELSE matchedStmt  {$$ = TreeNode::CreateIfStmt($2, $4, $6, $1);}
    | WHILE simpleExp DO matchedStmt                {$$ = TreeNode::CreateWhileStmt($2, $4, $1);}
    | FOR ID ASSIGN iterRange DO matchedStmt        {$$ = TreeNode::CreateForStmt($2, $4, $6, $1);}
    | otherStmts                                    {$$ = $1;}
    ;

unmatchedStmt:
    IF simpleExp THEN selectStmt                            {$$ = TreeNode::CreateIfStmt($2, $4, nullptr, $1);}
    | IF simpleExp THEN matchedStmt ELSE unmatchedStmt      {$$ = TreeNode::CreateIfStmt($2, $4, $6, $1);}
    | WHILE simpleExp DO unmatchedStmt                      {$$ = TreeNode::CreateWhileStmt($2, $4, $1);}
    | FOR ID ASSIGN iterRange DO unmatchedStmt              {$$ = TreeNode::CreateForStmt($2, $4, $6, $1);}
    ;

iterRange:
    simpleExp TO simpleExp                {$$ = TreeNode::CreateRangeStmt($1, $3, nullptr, $2);}
    | simpleExp TO simpleExp BY simpleExp   {$$ = TreeNode::CreateRangeStmt($1, $3, $5, $2);}
    ;

returnStmt:
    RETURN SEMICOLON        {$$ = TreeNode::CreateReturnStmt(nullptr, $1);}
    | RETURN exp SEMICOLON  {$$ = TreeNode::CreateReturnStmt($2, $1);}
    ;

breakStmt:
    BREAK SEMICOLON         {$$ = TreeNode::CreateBreakStmt(nullptr, $1);}
    | BREAK exp SEMICOLON   {$$ = TreeNode::CreateBreakStmt($2, $1);}
    ;

exp:
    mutable ASSIGN exp      {$$ = TreeNode::CreateAssignExp($1, $3, $2);}
    | mutable ADDASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2);}
    | mutable SUBASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2);}
    | mutable MULASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2);}
    | mutable DIVASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2);}
    | mutable INC           {$$ = TreeNode::CreateAssignExp($1, nullptr, $2);}
    | mutable DEC           {$$ = TreeNode::CreateAssignExp($1, nullptr, $2);}
    | simpleExp             {$$ = $1;}
    ;

simpleExp:
    simpleExp OR andExp {$$ = TreeNode::CreateOpExp($1, $3, $2);}
    | andExp            {$$ = $1;}
    ;

andExp:
    andExp AND unaryRelExp  {$$ = TreeNode::CreateOpExp($1, $3, $2);}
    | unaryRelExp           {$$ = $1;}
    ;

unaryRelExp:
    NOT unaryRelExp {$$ = TreeNode::CreateOpExp($2, nullptr, $1);}
    | relExp        {$$ = $1;}
    ;

relExp:
    minmaxExp relop minmaxExp   {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr);}
    | minmaxExp                 {$$ = $1;}
    ;

relop:
    LEQ     {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | LT    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | GT    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | GEQ   {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | EQ    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | NEQ   {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

minmaxExp:
    minmaxExp minmaxop sumExp   {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr);}
    | sumExp                    {$$ = $1;}
    ;

minmaxop:
    MIN     {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | MAX   {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

sumExp:
    sumExp sumop mulExp {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr);}
    | mulExp            {$$ = $1;}
    ;

sumop:
    PLUS    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | MINUS {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

mulExp:
    mulExp mulop unaryExp   {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr);}
    | unaryExp              {$$ = $1;}
    ;

mulop:
    STAR        {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | DIVIDE    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | MOD       {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

unaryExp:
    unaryop unaryExp    {$$ = TreeNode::PullUpNode($1, $2, nullptr, nullptr);}
    | factor            {$$ = $1;}
    ;

unaryop:
    MINUS       {$$ = TreeNode::CreateUnaryOpExp($1);}
    | STAR      {$$ = TreeNode::CreateUnaryOpExp($1);}
    | QUESTION  {$$ = TreeNode::CreateUnaryOpExp($1);}
    ;

factor:
    immutable   {$$ = $1;}
    | mutable   {$$ = $1;}
    ;

mutable:
    ID                          {$$ = TreeNode::CreateIdExp($1);}
    | ID LBRACKET exp RBRACKET  {$$ = TreeNode::CreateIdxExp($3, $1, $2);}
    ;

immutable:
    LPAREN exp RPAREN   {$$ = $2;}
    | call              {$$ = $1;}
    | constant          {$$ = $1;}
    ;

call:
    ID LPAREN args RPAREN   {$$ = TreeNode::CreateCallExp($3, $1);}
    ;

args:
    argList {$$ = $1;}
    |       {$$ = nullptr;}
    ;

argList:
    argList COMMA exp   {$$ = TreeNode::NodeList($1, $3);}
    | exp               {$$ = $1;}
    ;

constant:
    NUMCONST        {$$ = TreeNode::CreateConstExp(TreeNode::VarType::INTEGER, $1);}
    | CHARCONST     {$$ = TreeNode::CreateConstExp(TreeNode::VarType::CHARACTER, $1);}
    | STRINGCONST   {$$ = TreeNode::CreateConstExp(TreeNode::VarType::STRING, $1);}
    | TRUE          {$$ = TreeNode::CreateConstExp(TreeNode::VarType::BOOLEAN, $1);}
    | FALSE         {$$ = TreeNode::CreateConstExp(TreeNode::VarType::BOOLEAN, $1);}
    ;

%%

void yyerror(const char* s)
{
    printf("Error!\n");
}

int main(int argc, char* argv[])
{
    yydebug = 0;

    if(argc > 2 || (argc == 1 && isatty(fileno(stdin)))) {
        printf("Invalid Usage! Correct usage is\n./c- <filename>\nor cat <filename> | ./c-\nor ./c- < <filename>\n");
        return 2;
    }

    if(argc == 2) {
        FILE* file = fopen(argv[1], "r");
        if(!file) {
            perror(argv[1]);
            return 1;
        }

        yyin = file;
    }

    yyparse();

    ASTRoot->Print();
    return 0;
}