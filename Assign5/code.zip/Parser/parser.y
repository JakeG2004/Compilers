%code requires {
#include "treenode.h"
#include "tokenclass.h"
}

%define parse.error verbose
%debug

%{
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "errorhandler.h"
#include "arghandler.h"
#include "treenode.h"
#include "semanticanalyzer.h"

int yylex(void);
void yyerror(const char*);

extern FILE* yyin;
extern int yydebug;
extern int yylineno;
extern int lastLineNo;
extern char* yytext;

TreeNode* ASTRoot = nullptr;
%}

%union {
    int NUMBER;
    TreeNode::VarType varType;
    TreeNode* node;
    TokenClass* tokenData;
};

%token <tokenData> ID NUMCONST CHARCONST STRINGCONST SEMICOLON STATIC COMMA COLON LBRACKET RBRACKET LPAREN RPAREN LBRACE RBRACE ASSIGN ADDASS SUBASS MULASS DIVASS INC DEC LEQ LT GT GEQ EQ NEQ MIN MAX PLUS MINUS STAR DIVIDE MOD QUESTION INT BOOL CHAR IF THEN ELSE WHILE DO FOR RETURN TO BY BREAK OR AND NOT TRUE FALSE
%type <node> program declList decl varDecl scopedVarDecl varDeclList varDeclInit varDeclId funDecl parms parmList parmTypeList parmIdList parmId stmt otherStmts expStmt compoundStmt localDecls stmtList selectStmt matchedStmt unmatchedStmt iterRange returnStmt breakStmt exp simpleExp andExp unaryRelExp relExp relop minmaxExp minmaxop sumExp sumop mulExp mulop unaryExp unaryop factor mutable immutable call args argList constant
%type <varType> typeSpec

%%
program:
    declList    {ASTRoot = $1;}
    ;

declList:
    declList decl   {$$ = TreeNode::NodeList($1, $2);}
    | decl          {$$ = $1;}
    ;

decl:
    varDecl             {$$ = $1;}
    | funDecl           {$$ = $1;}   
    | error SEMICOLON   {$$ = nullptr; yyerrok; }
    ;

varDecl:
    typeSpec varDeclList SEMICOLON  {$$ = TreeNode::PullUpTypeNode($2, $1); TreeNode::SetNodeListTypes($1, $2);}
    ;

scopedVarDecl:
    STATIC typeSpec varDeclList SEMICOLON   {$$ = TreeNode::PullUpTypeNode($3, $2); for(TreeNode* v = $$; v != nullptr; v = v->sibling) v->isStatic = true; TreeNode::SetNodeListTypes($2, $3);}
    | typeSpec varDeclList SEMICOLON        {$$ = TreeNode::PullUpTypeNode($2, $1); TreeNode::SetNodeListTypes($1, $2);}
    | error SEMICOLON                       {$$ = nullptr; yyerrok; }
    | typeSpec error SEMICOLON              {$$ = nullptr; yyerrok; }
    ;

varDeclList:
    varDeclList COMMA varDeclInit   {$$ = TreeNode::NodeList($1, $3);}
    | varDeclInit                   {$$ = $1;}
    ;

varDeclInit:
    varDeclId                   {$$ = $1;}
    | varDeclId COLON simpleExp {$$ = TreeNode::PullUpNode($1, $3, nullptr, nullptr);}
    ;

varDeclId:
    ID                              {$$ = TreeNode::CreateVarDecl(nullptr, $1);}
    | ID LBRACKET NUMCONST RBRACKET {$$ = TreeNode::CreateVarDecl($3, $1); $$->isArray = true;}
    ;

typeSpec:
    INT     {$$ = TreeNode::VarType::INTEGER;} 
    | BOOL  {$$ = TreeNode::VarType::BOOLEAN;}
    | CHAR  {$$ = TreeNode::VarType::CHARACTER;}
    ;

funDecl:
    typeSpec ID LPAREN parms RPAREN stmt    {$$ = TreeNode::CreateFuncDecl($1, $4, $6, $2);}
    | ID LPAREN parms RPAREN stmt           {$$ = TreeNode::CreateFuncDecl(TreeNode::VarType::VOID, $3, $5, $1);}
    | error RPAREN stmt                     {$$ = nullptr; yyerrok; }
    ;

parms:
    parmList    {$$ = $1;}
    |           {$$ = nullptr;}
    ;

parmList:
    parmList SEMICOLON parmTypeList {$$ = TreeNode::NodeList($1, $3);}
    | parmTypeList                  {$$ = $1;}
    | error SEMICOLON               {$$ = nullptr; yyerrok; }
    ;

parmTypeList:
    typeSpec parmIdList {$$ = $2; TreeNode::SetNodeListTypes($1, $2);}
    ;

parmIdList:
    parmIdList COMMA parmId {$$ = TreeNode::NodeList($1, $3);}
    | parmId                {$$ = $1;}
    ;

parmId:
    ID                      {$$ = TreeNode::CreateParmDecl($1);}
    | ID LBRACKET RBRACKET  {$$ = TreeNode::CreateParmDecl($1); $$->isArray = true;}
    ;

stmt:
    selectStmt  {$$ = $1;}
    ;

otherStmts:
    expStmt         {$$ = $1;}
    | compoundStmt  {$$ = $1;}
    | returnStmt    {$$ = $1;}
    | breakStmt     {$$ = $1;}
    ;

expStmt:
    exp SEMICOLON       {$$ = $1; if($$) $$->isStmtExp = true;}
    | SEMICOLON         {$$ = nullptr;}
    | error SEMICOLON   {$$ = nullptr; yyerrok; }
    ;

compoundStmt:
    LBRACE localDecls stmtList RBRACE   {$$ = TreeNode::CreateCompoundStmt($2, $3, $1);}
    | LBRACE error RBRACE               {$$ = nullptr; yyerrok; }
    ;

localDecls:
    localDecls scopedVarDecl    {$$ = TreeNode::NodeList($1, $2);}
    |                           {$$ = nullptr;}
    ;

stmtList:
    stmtList stmt   {$$ = TreeNode::NodeList($1, $2);}
    |               {$$ = nullptr;}
    ;

selectStmt:
    matchedStmt             {$$ = $1;}
    | unmatchedStmt         {$$ = $1;}
    | FOR error RBRACE      {$$ = nullptr; yyerrok; }
    | WHILE error RBRACE    {$$ = nullptr; yyerrok; }
    | IF error RBRACE       {$$ = nullptr; yyerrok; }
    ;

matchedStmt:
    IF simpleExp THEN matchedStmt ELSE matchedStmt  {$$ = TreeNode::CreateIfStmt($2, $4, $6, $1);}
    | WHILE simpleExp DO matchedStmt                {$$ = TreeNode::CreateWhileStmt($2, $4, $1);}
    | FOR ID ASSIGN iterRange DO matchedStmt        {$$ = TreeNode::CreateForStmt($4, $6, $2, $1);}
    | otherStmts                                    {$$ = $1;}
    ;

unmatchedStmt:
    IF simpleExp THEN selectStmt                            {$$ = TreeNode::CreateIfStmt($2, $4, nullptr, $1);}
    | IF simpleExp THEN matchedStmt ELSE unmatchedStmt      {$$ = TreeNode::CreateIfStmt($2, $4, $6, $1);}
    | WHILE simpleExp DO unmatchedStmt                      {$$ = TreeNode::CreateWhileStmt($2, $4, $1);}
    | FOR ID ASSIGN iterRange DO unmatchedStmt              {$$ = TreeNode::CreateForStmt($4, $6, $2, $1);}
    ;

iterRange:
    simpleExp TO simpleExp                  {$$ = TreeNode::CreateRangeStmt($1, $3, nullptr, $2);}
    | simpleExp TO simpleExp BY simpleExp   {$$ = TreeNode::CreateRangeStmt($1, $3, $5, $2);}
    ;

returnStmt:
    RETURN SEMICOLON        {$$ = TreeNode::CreateReturnStmt(nullptr, $1);}
    | RETURN exp SEMICOLON  {$$ = TreeNode::CreateReturnStmt($2, $1);}
    ;

breakStmt:
    BREAK SEMICOLON         {$$ = TreeNode::CreateBreakStmt(nullptr, $1);}
    | BREAK exp SEMICOLON   {$$ = TreeNode::CreateBreakStmt($2, $1);}
    ;

exp:
    mutable ASSIGN exp      {$$ = TreeNode::CreateAssignExp($1, $3, $2); $$->varType = $3 ? $3->varType : TreeNode::VarType::UNDEFINED; }
    | mutable ADDASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2); $$->varType = TreeNode::VarType::INTEGER; }
    | mutable SUBASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2); $$->varType = TreeNode::VarType::INTEGER; }
    | mutable MULASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2); $$->varType = TreeNode::VarType::INTEGER; }
    | mutable DIVASS exp    {$$ = TreeNode::CreateAssignExp($1, $3, $2); $$->varType = TreeNode::VarType::INTEGER; }
    | mutable INC           {$$ = TreeNode::CreateAssignExp($1, nullptr, $2); $$->varType = TreeNode::VarType::INTEGER; }
    | mutable DEC           {$$ = TreeNode::CreateAssignExp($1, nullptr, $2); $$->varType = TreeNode::VarType::INTEGER; }
    | simpleExp             {$$ = $1;}
    ;

simpleExp:
    simpleExp OR andExp {$$ = TreeNode::CreateOpExp($1, $3, $2); $$->varType = TreeNode::VarType::BOOLEAN; }
    | andExp            {$$ = $1;}
    ;

andExp:
    andExp AND unaryRelExp  {$$ = TreeNode::CreateOpExp($1, $3, $2); $$->varType = TreeNode::VarType::BOOLEAN; }
    | unaryRelExp           {$$ = $1;}
    ;

unaryRelExp:
    NOT unaryRelExp {$$ = TreeNode::CreateOpExp($2, nullptr, $1); $$->varType = TreeNode::VarType::BOOLEAN; }
    | relExp        {$$ = $1;}
    ;

relExp:
    minmaxExp relop minmaxExp   {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr); $$->varType = TreeNode::VarType::BOOLEAN; }
    | minmaxExp                 {$$ = $1;}
    ;

relop:
    LEQ     {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | LT    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | GT    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | GEQ   {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | EQ    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | NEQ   {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

minmaxExp:
    minmaxExp minmaxop sumExp   {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr); $$->varType = TreeNode::VarType::INTEGER; }
    | sumExp                    {$$ = $1;}
    ;

minmaxop:
    MIN     {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1); $$->varType = TreeNode::VarType::INTEGER; }
    | MAX   {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1); $$->varType = TreeNode::VarType::INTEGER; }
    ;

sumExp:
    sumExp sumop mulExp {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr); $$->varType = TreeNode::VarType::INTEGER; }
    | mulExp            {$$ = $1;}
    ;

sumop:
    PLUS    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | MINUS {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

mulExp:
    mulExp mulop unaryExp   {$$ = TreeNode::PullUpNode($2, $1, $3, nullptr); $$->varType = TreeNode::VarType::INTEGER; }
    | unaryExp              {$$ = $1;}
    ;

mulop:
    STAR        {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | DIVIDE    {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    | MOD       {$$ = TreeNode::CreateOpExp(nullptr, nullptr, $1);}
    ;

unaryExp:
    unaryop unaryExp    {$$ = TreeNode::PullUpNode($1, $2, nullptr, nullptr);}
    | factor            {$$ = $1;}
    ;

unaryop:
    MINUS       {$$ = TreeNode::CreateUnaryOpExp($1);}
    | STAR      {$$ = TreeNode::CreateUnaryOpExp($1);}
    | QUESTION  {$$ = TreeNode::CreateUnaryOpExp($1);}
    ;

factor:
    immutable   {$$ = $1;}
    | mutable   {$$ = $1;}
    ;

mutable:
    ID                          {$$ = TreeNode::CreateIdExp($1);}
    | ID LBRACKET exp RBRACKET  {$$ = TreeNode::CreateIdxExp($3, $1, $2); $$->varType = $3->varType; }
    ;

immutable:
    LPAREN exp RPAREN   {$$ = $2;}
    | call              {$$ = $1;}
    | constant          {$$ = $1;}
    | error RPAREN      {$$ = nullptr; yyerrok;}
    | error RBRACKET    {$$ = nullptr; yyerrok;}
    ;

call:
    ID LPAREN args RPAREN   {$$ = TreeNode::CreateCallExp($3, $1);}
    ;

args:
    argList {$$ = $1;}
    |       {$$ = nullptr;}
    ;

argList:
    argList COMMA exp   {$$ = TreeNode::NodeList($1, $3);}
    | exp               {$$ = $1;}
    ;

constant:
    NUMCONST        {$$ = TreeNode::CreateConstExp(TreeNode::VarType::INTEGER, $1); $$->isConst = true; }
    | CHARCONST     {$$ = TreeNode::CreateConstExp(TreeNode::VarType::CHARACTER, $1);$$->isConst = true; }
    | STRINGCONST   {$$ = TreeNode::CreateConstExp(TreeNode::VarType::CHARACTER, $1); $$->isArray = true; $$->isConst = true; }
    | TRUE          {$$ = TreeNode::CreateConstExp(TreeNode::VarType::BOOLEAN, $1); $$->isConst = true; }
    | FALSE         {$$ = TreeNode::CreateConstExp(TreeNode::VarType::BOOLEAN, $1); $$->isConst = true; }
    ;

%%

static const struct { const char* name; const char* spelling; } tokenSpellings[] = {
    // A
    {"AND", "\"and\""}, 
    {"ASSIGN", "'='"}, 
    {"ADDASS", "\"+=\""},
    // B
    {"BOOL", "\"bool\""},
    {"BY", "\"by\""}, 
    {"BREAK", "\"break\""}, 
    {"BOOLCONST", "Boolean constant"},
    // C
    {"COLON", "':'"}, 
    {"COMMA", "','"},
    {"CHAR", "\"char\""},
    {"CHARCONST", "character constant"},
    // D
    {"DIVASS", "\"/=\""},
    {"DIVIDE", "'/'"}, 
    {"DO", "\"do\""}, 
    {"DEC", "\"--\""},
    // E
    {"EQ", "\"==\""}, 
    {"ELSE", "\"else\""}, 
    {"$end", "end of input"},
    // F
    {"FOR", "\"for\""},
    {"FALSE", "Boolean constant"},
    // G
    {"GT", "'>'"}, 
    {"GEQ", "\">=\""},
    // H
    // I
    {"INC", "\"++\""}, 
    {"INT", "\"int\""}, 
    {"IF", "\"if\""}, 
    {"ID", "identifier"},
    // J
    // K
    // L
    {"LBRACKET", "'['"}, 
    {"LPAREN", "'('"}, 
    {"LBRACE", "'{'"}, 
    {"LEQ", "\"<=\""}, 
    {"LT", "'<'"}, 
    // M
    {"MULASS", "\"*=\""}, 
    {"MIN", "\"<<\""}, 
    {"MAX", "\">>\""},
    {"MINUS", "'-'"}, 
    {"MOD", "'%'"}, 
    // N
    {"NEQ", "\"!=\""}, 
    {"NOT", "\"not\""}, 
    {"NUMCONST", "numeric constant"},
    // O
    {"OR", "\"or\""}, 
    // P
    {"PLUS", "'+'"}, 
    // Q
    {"QUESTION", "'?'"},
    // R
    {"RBRACKET", "']'"}, 
    {"RETURN", "\"return\""}, 
    {"RPAREN", "')'"}, 
    {"RBRACE", "'}'"},
    // S 
    {"SEMICOLON", "';'"}, 
    {"SUBASS", "\"-=\""},  
    {"STAR", "'*'"}, 
    {"STATIC", "\"static\""}, 
    {"STRINGCONST", "string constant"},
    // T
    {"THEN", "\"then\""}, 
    {"TO", "\"to\""}, 
    {"TRUE", "Boolean constant"}, 
    // U
    // V
    // W
    {"WHILE", "\"while\""}, 
    // X
    // Y
    // Z
};

void yyerror(const char* s)
{
    std::string in(s), out;

    for(size_t k; (k = in.find("end of file")) != std::string::npos;)
        in.replace(k, 11, "end_of_input");

    for(size_t i = 0; i < in.size();) {
        size_t j = i;
        while(j < in.size() && ((in[j] >= 'A' && in[j] <= 'Z') || in[j] == '_'))
            j++;

        if(j == i) {
            out += in[i++];
            continue;
        }

        std::string word = in.substr(i, j - i);
        for(const auto& t : tokenSpellings)
            if(word == t.name) {
                word = t.spelling;
                break;
            }
        out += word;
        i = j;
    }

    ErrorHandler::AddSyntaxError(out, yytext, lastLineNo);
}

bool ProcessFlags(bool* stDebugFlag, bool* printFlag, bool* typePrintFlag)
{
    if(ArgHandler::IsFlagSet("-d"))
        yydebug = 1;
    if(ArgHandler::IsFlagSet("-D"))
        *stDebugFlag = true;
    if(ArgHandler::IsFlagSet("-h")) {
        ArgHandler::PrintHelp();
        return false;
    }
    if(ArgHandler::IsFlagSet("-p"))
        *printFlag = true;
    if(ArgHandler::IsFlagSet("-P"))
        *printFlag = true;

    return true;
}

bool OpenFile(int argc, char* argv[])
{
    const char* filePath = nullptr;
    for(int i = 1; i < argc; i++) {
        if(argv[i][0] != '-')
            filePath = argv[i];
    }

    if(filePath) {
        FILE* file = fopen(filePath, "r");
        if(!file) {
            perror(filePath);
            return false;
        }
        yyin = file;
    } else {
        yyin = stdin;
    }

    if(yyin == NULL) {
        printf("YYIN IS NULL!!!!!! BAD!!!!\n");
        return false;
    }

    //printf("====================================\n");
    //printf("FILE: %s\n", filePath);

    return true;
}

int main(int argc, char* argv[])
{
    // argument flags
    yydebug = 0;
    bool printFlag = false;
    bool typePrintFlag = false;
    bool stDebugFlag = false;

    ArgHandler::ProcessArgs(argc, argv);
    if(!ProcessFlags(&stDebugFlag, &printFlag, &typePrintFlag))
        return 0;

    if(!OpenFile(argc, argv))
        return 2;

    int result = yyparse();

    //printf("Done parsing\n");

    if(ErrorHandler::GetNumErrors() != 0) {
        std::cout << "Number of warnings: " << ErrorHandler::GetNumWarnings() << std::endl;
        std::cout << "Number of errors: " << ErrorHandler::GetNumErrors() << std::endl;
        return 3;
    }

    SemanticAnalyzer* analyzer = new SemanticAnalyzer(stDebugFlag);
    analyzer->StartAnalysis(ASTRoot);

    if((printFlag || typePrintFlag) && ASTRoot && ErrorHandler::GetNumErrors() == 0)
        ASTRoot->Print(0, -1, 0, typePrintFlag);

    std::cout << "Number of warnings: " << ErrorHandler::GetNumWarnings() << std::endl;
    std::cout << "Number of errors: " << ErrorHandler::GetNumErrors() << std::endl;

    return 0;
}